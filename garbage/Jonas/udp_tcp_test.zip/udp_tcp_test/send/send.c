// get the file send it to the receiver
