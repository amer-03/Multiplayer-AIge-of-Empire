// read the file from the sender, write it in obj.pickle
